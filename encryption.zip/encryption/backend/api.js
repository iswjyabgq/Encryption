const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const Users = require("./usersModel.js");

const hashPassword = async (password) => {
  try {
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    return hashedPassword;
  } catch {
    return "Internal server error!";
  }
};

const saveUserDetails = async (req, res) => {
  try {
    const { email, name, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: "Email or Password is required!" });

    const query = {};
    query.Email = email.toLowerCase();
    const existingEmail = await Users.findOne(query);
    if (existingEmail) {
      return res
        .status(200)
        .json({ code: 400, message: "Email Id already exist!" });
    }

    const hashedPassword = await hashPassword(password);
    const user = new Users({
      Name: name,
      Email: email.toLowerCase(),
      Password: hashedPassword,
    });
    await user.save();
    return res.status(200).json({ code: 200, message: "success" });
  } catch (error) {
    return res.status(500).json({ error });
  }
};

router.post("/saveData", saveUserDetails);

module.exports = router;
