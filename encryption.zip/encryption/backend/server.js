const express = require("express");
const cors = require("cors");
require("dotenv").config();

const connectToMongoDB = require("./db");

const app = express();
const PORT = 5555;

const corsOptions = {
  origin: ["http://localhost:3333"],
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: true,
};

app.use(cors(corsOptions));
app.use(express.json());

app.use("/api", require("./api"));

app.listen(process.env.PORT || PORT, async () => {
  await connectToMongoDB();
  console.log(`Server running on http://localhost:${PORT}`);
});
