const { default: mongoose } = require("mongoose");

let db = null;

async function connectToMongoDB() {
  if (db) return db;

  const url = process.env.MONGO_URL;

  try {
    await mongoose.connect(url);
    console.log("Connected successfully to MongoDB");
  } catch (err) {
    console.error("Connection error:", err);
    throw err;
  }
}

module.exports = connectToMongoDB;
