const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const user = new Schema({
  Name: {
    type: String,
    required: true,
    maxlength: 100,
  },
  Email: {
    type: String,
    unique: true,
    maxlength: 100,
    required: true,
    validate: {
      validator: function (v) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      },
      message: (props) => `${props.value} is not a valid email address!`,
    },
  },
  Password: {
    type: String,
    required: true,
  },
});

const Users = mongoose.model("users", user);
module.exports = Users;
