import React, { useState } from "react";
import axios from "axios";
import {
  Box,
  Button,
  Checkbox,
  CssBaseline,
  FormControl,
  FormControlLabel,
  FormLabel,
  TextField,
  Typography,
  Card,
  Stack,
  InputAdornment,
  IconButton,
} from "@mui/material";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import CircularProgress from "@mui/material/CircularProgress";
import Backdrop from "@mui/material/Backdrop";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const darkTheme = createTheme({
  palette: {
    mode: "dark",
    background: {
      default: "#050D1D",
      paper: "#0B1A2F",
    },
    primary: {
      main: "#E4E9F5",
    },
  },
  typography: {
    fontFamily: "Inter, sans-serif",
    fontSize: 14,
  },
  shape: {
    borderRadius: 8,
  },
});

const apiUrl = import.meta.env.VITE_API_URL;

const header = { "Content-Type": "application/json" };

const SignUp = () => {
  const [inputs, setInputs] = useState({ name: "", email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setInputs((prev) => ({ ...prev, [name]: value }));
  };

  const apiConnection = async () => {
    try {
      setLoading(true);
      const data = {
        name: inputs.name,
        email: inputs.email,
        password: inputs.password,
      };
      const config = {
        method: "POST",
        url: `${apiUrl}/api/saveData`,
        data,
        header,
      };
      const res = await axios(config);
      if (res.data.code === 200) {
        setInputs({ name: "", email: "", password: "" });
        toast("User details saved successfully.");
      } else toast(res.data?.message);
    } catch {
      toast("Something went wrong...");
    } finally {
      setLoading(false);
    }
  };

  const validation = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (inputs.name.trim().length === 0) return "Full Name is required!";
    if (inputs.email.trim().length === 0) return "Email is required!";
    if (!emailRegex.test(inputs.email)) return "Invalid Email Id!";
    if (inputs.password.trim().length === 0) return "Password is required!";
    if (inputs.password.trim().length < 8)
      return "Password must be at least 8 characters!";
    return null;
  };

  const handleSubmit = async () => {
    const errMsg = validation();
    if (errMsg) {
      toast(errMsg);
      return;
    }
    await apiConnection();
  };

  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      <ToastContainer
        position="top-center"
        autoClose={2000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        pauseOnFocusLoss
        draggable
        pauseOnHover
        toastStyle={{ backgroundColor: "#000000", color: "#fff" }}
      />
      {loading && (
        <Backdrop open={open} style={{ color: "deepskyblue", zIndex: 1301 }}>
          <CircularProgress color="inherit" />
        </Backdrop>
      )}
      <Box
        sx={{
          minHeight: "100vh",
          background:
            "radial-gradient(circle at center, #051727 0%, #050D1D 100%)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          p: 2,
        }}
      >
        <Card
          sx={{
            width: "100%",
            maxWidth: 520,
            p: 4,
            display: "flex",
            flexDirection: "column",
            gap: 2,
            boxShadow:
              "0 0 0 1px rgba(255, 255, 255, 0.05), 0 10px 40px rgba(0,0,0,0.6)",
            borderRadius: 2,
            bgcolor: "background.paper",
          }}
          className="card-hover"
        >
          <Box sx={{ mb: 2 }}>
            <Typography
              className="text-center"
              variant="h4"
              color="primary"
              sx={{ fontWeight: 600 }}
            >
              <span style={{ color: "#3AB8F8" }}>✶</span> Sign up
            </Typography>
          </Box>
          <Stack component="form" spacing={2}>
            <FormControl fullWidth>
              <FormLabel sx={{ color: "text.primary" }}>Full Name</FormLabel>
              <TextField
                placeholder="Test User"
                name="name"
                variant="outlined"
                value={inputs.name}
                className="text-field"
                onChange={handleChange}
                fullWidth
                autoComplete="name"
                InputProps={{ sx: { bgcolor: "black" } }}
              />
            </FormControl>

            <FormControl fullWidth>
              <FormLabel sx={{ color: "text.primary" }}>Email Id</FormLabel>
              <TextField
                placeholder="test@gmail.com"
                name="email"
                type="email"
                variant="outlined"
                className="text-field"
                value={inputs.email}
                onChange={handleChange}
                fullWidth
                autoComplete="email"
                InputProps={{ sx: { bgcolor: "black" } }}
              />
            </FormControl>

            <FormControl fullWidth>
              <FormLabel sx={{ color: "text.primary" }}>Password</FormLabel>
              <TextField
                placeholder="••••••"
                name="password"
                type={showPassword ? "text" : "password"}
                className="text-field"
                value={inputs.password}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSubmit();
                }}
                onChange={handleChange}
                variant="outlined"
                fullWidth
                autoComplete="new-password"
                InputProps={{
                  sx: { bgcolor: "black" },
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label={
                          showPassword ? "Hide password" : "Show password"
                        }
                        onClick={() => setShowPassword((prev) => !prev)}
                        onMouseDown={(e) => e.preventDefault()}
                        edge="end"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </FormControl>

            <FormControlLabel
              control={<Checkbox color="primary" />}
              label={
                <Typography variant="body2">
                  Agree Terms and Conditions.
                </Typography>
              }
              sx={{ mt: 1 }}
            />

            <Button
              variant="contained"
              color="primary"
              title="Click here to sign up"
              onClick={handleSubmit}
              fullWidth
              sx={{
                mt: 1,
                fontWeight: 600,
                bgcolor: "#E4E9F5",
                color: "#000",
                textTransform: "none",
                "&:hover": {
                  bgcolor: "#0251eeff",
                },
              }}
            >
              Sign up
            </Button>
          </Stack>
        </Card>
      </Box>
    </ThemeProvider>
  );
};

export default SignUp;
